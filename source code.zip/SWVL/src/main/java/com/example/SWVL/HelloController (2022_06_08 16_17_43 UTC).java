package com.example.SWVL;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class HelloController {
    @FXML
    private TextField Location;
    @FXML
    public TextField Destination;
    @FXML
    public TextField RideType;

    public void showRides(){

       /* try {

            Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/onlineshopping", "root","");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from customer");
            boolean found = false;
            while (rs.next()) {
                if(getEmail.equals(rs.getString(3))){
                    if(getPass.equals(rs.getString(4))){
                        found = true;
                        break;
                    }

                }
            }
            if(found){
                Stage s = (Stage) pass.getScene().getWindow();
                Parent root2 = FXMLLoader.load(getClass().getResource("view-sport-items.fxml"));
                s.setScene(new Scene(root2));
                s.show();
            }
        }catch (Exception e){
            System.out.println(e);
        }*/
        Stage s = new Stage();
        Parent root2 = null;
        try {
            root2 = FXMLLoader.load(getClass().getResource("viewRides.fxml"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        s.setScene(new Scene(root2));
        s.show();
    }

}