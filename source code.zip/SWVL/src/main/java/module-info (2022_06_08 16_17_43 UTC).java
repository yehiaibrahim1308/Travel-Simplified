module com.example.SWVL {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.SWVL to javafx.fxml;
    exports com.example.SWVL;
}